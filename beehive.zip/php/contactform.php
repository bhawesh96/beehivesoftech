<?php 

//Connect to database
	include_once('conn.php');

if(!$db_selected)
{
	die('cannot access' . $dbname . ':' . mysql_error());
 }

//Fetch HTML form details
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $message = $_POST['message'];
 

$sql = "INSERT INTO contactform (email, phone, message) VALUES ('$email', '$phone', '$message')";  		

if(!mysql_query($sql))
{
	echo mysql_error();
}

else{
	echo 'Your message has been successfully sent!';
}

mysql_close();







 ?>
