<?php 

	$username = 'beehipfc_user';
	$pass = 'clandestine1996';
	$dbname = 'beehipfc_name';
	$host = 'localhost';

	$db = @mysql_connect($host, $username, $pass);

	if(!$db){
		 die('failed to connect' . mysql_error());
	}

	$db_selected = @mysql_select_db($dbname, $db);


 ?>
